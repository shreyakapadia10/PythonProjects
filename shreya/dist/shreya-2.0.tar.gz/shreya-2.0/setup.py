from setuptools import setup

setup(name="shreya",
      version="2.0",
      description="This is a Stone, Paper, Scissors Package",
      long_description="This package can be used to play Stone, Paper, Scissors Package. It'll give user 10 chances",
      author="Shreya Kapadia",
      packages=["shreya"],
      install_requires=[])
